
function scrolll(){
    const container = document.querySelector(".scroll-test");
    container.scrollBy(-100, 0);
}
function scrollr(){
    const container = document.querySelector(".scroll-test");
    container.scrollBy(100, 0);
}   